<php? 
$app =  newApp()
$app->run();
