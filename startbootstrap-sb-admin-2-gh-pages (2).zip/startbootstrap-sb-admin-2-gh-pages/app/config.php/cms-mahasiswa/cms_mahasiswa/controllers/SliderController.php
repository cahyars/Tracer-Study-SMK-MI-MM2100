<?php

class SlideController extends Controller {
    private $model;
    private function _construct(){ $this->model = new Slider(); }

    public function index(){
        $items = $this->model->all();
        $this->view('slider/index',['items'=>$items]);
    }
    public function create(){
        if($_SERVER['REQUEST_METHOD']==='POST'){
            $gambar = null;
            if(!empty($_FILES['gambar']['name'])){
                $ext = pathinfo($_FILES['gambar']['name'], PATHINFO_EXTENSION);
                $name = uniqid().'.'.$ext;
                if(!is_dir(UPLOAD_DIR)) mkdir(UPLOAD_DIR,0755,true);
                move_uploaded_file($_FILES['gambar']['tmp_name'], UPLOAD_DIR.$name);
                $gambar = $name;
            }
            $data = [
                'judul' =>$_POST['judul'],
                'deskripsi' =>$_POST['deskripsi'],
                'gambar' =>$gambar
            
            ];
            $this->model->create($data);
            $this->redirect(BASE_URL.'/index.php?url=slider/index');
        }
        $this->view('slider/create');
    }

    public function edit($id){
        $item = $this->model->find($id);
        if(!$item){ echo 'Sider tidak ditemukan'; exit;}
        if($_SERVER['REQUEST_METHOD']==='POST'){
            $gambar = $item->gambar;
            if(!empty($_FILES['gambar']['name'])){
            $ext = pathinfo($_FILES['gambar']['name'], PATHINFO);
            $name = uniqid().'.'.$ext;
            if(!is_dir(UPLOAD_DIR)) mkdir(UPLOAD_DIR,0755,true);
            move_uploaded_file($_FILES['gambar']['tmp_name'], UPLOAD_DIR.$name);
            if($item->gambar && file_exists(UPLOAD_DIR.$item->gambar));
            $gambar = $name;
            }

            $data = [
            'judul' => $_POST['judul'],
            'deskripsi' => $_POST['deskripsi'],
            'gambar' => $gambar
            ];
            $this ->model->update($id, $data);
            $this->redirect(BASE_URL.'index.php?url=slider/index');
        }

     $this->view('mahasiswa/edit', ['item'=>$item]);
    }

public function delete($id){
    $item = $this->model->find($id);
    if($item && $item->info && file_exists(UPLOAD_DIR.$item->foto)) unlink(UPLOAD_DIR.$item->foto);
    $this->model->delete($id);
    $this->redirect(BASE_URL.'/index.php?url=mahasiswa/index');
}
    }