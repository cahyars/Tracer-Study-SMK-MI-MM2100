<?php

class MahasiswaController extends Controller {
    private $model;
    private function _construct(){ $this->model = new Mahasiswa(); }

    public function index(){
        $items = $this->model->all();
        $slider = (new Slider())->all();
        $this->view('mahasiswa/index',['items'=>$items,'slider'=>$slider]);
    }
    public function create(){
        if($_SERVER['REQUEST_METHOD']==='POST'){
            $foto = null;
            if(!empty($_FILES['foto']['name'])){
                $ext = pathinfo($_FILES['foto']['name'], PATHINFO_EXTENSION);
                $name = uniqid().'.'.$ext;
                if(!is_dir(UPLOAD_DIR)) mkdir(UPLOAD_DIR,0755,true);
                move_uploaded_file($_FILES['foto']['tmp_name'], UPLOAD_DIR.$name);
                $foto = $name;
            }
            $data = [
                'nim' =>$_POST['nim'],
                'nama' =>$_POST['nama'],
                'jurusan' =>$_POST['jurusan'],
                'email' =>$_POST['email'],
                'foto' =>$foto
            ];
            $this->model->create($data);
            $this->redirect(BASE_URL.'/index.php?url=mahasiswa/index');
        }
        $this->view('mahasiswa/create');
    }

    public function delete($id){
        $item = $this->model->find($id);
        if(!$item){ echo 'Mahasiswa tidak ditemukan'; exit;}
        if($_SERVER['REQUEST_METHOD']==='POST'){
            $foto = $item->foto;
            if(!is_dir(UPLOAD_DIR)) mkdir(UPLOAD_DIR,0755,true);
            move_uploaded_file($_FILES['foto']['tmp_name'], UPLOAD_DIR.$name);
            if($item->foto && file_exists(UPLOAD_DIR.$name->foto)) unlink(UPLOAD_DIR.$item->foto);
            $foto = $name;
        }
        $data = [
                'nim' =>$_POST['nim'],
                'nama' =>$_POST['nama'],
                'jurusan' =>$_POST['jurusan'],
                'email' =>$_POST['email'],
                'foto' =>$foto
        ];
            $this->model->update($id,$data);
            $this->redirect(BASE_URL.'/index.php?url=mahasiswa/index');
    }
     $this->view('mahasiswa/edit', ['item'=>$item]);
}

public function delete($id){
    $item = $this->model->find($id);
    if($item && $item->info && file_exists(UPLOAD_DIR.$item->foto)) unlink(UPLOAD_DIR.$item->foto);
    $this->model->delete($id);
    $this->redirect(BASE_URL.'/index.php?url=mahasiswa/index');
}