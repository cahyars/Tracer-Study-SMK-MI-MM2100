<?php
class Slider extends Model {
    private $table = 'slider';
    public function all(){
        $stmt = $this->db->query("SELECT * FROM $this ->table ORDER BY id DESC");
        return $stmt->fetchAll();
    }
    public function find($id){
        $stmt = $this->db->prepare("SELECT * FROM $this->table WHERE id=?");
        $stmt->execute([$id]);
        return $stmt->fetch();
    }
    public function create($data){
        $stmt = $this->db->prepare("INSERT INTO $this->table (judul, deskripsi, gambar VALUES (?,?,?");
        return $stmt->execute ([$data['judul'],$data['deskripsi'],$data['gambar']]);
    }
    public function update($id,$data){
        $stmt = $this->db->prepare("UPDATE $this->table SET judul=?, nama=?, deskripsi=?, gambar=?, WHERE id=?");
        return $stmt->execute ([$data['judul'],$data['deskripsi'],$data['gambar'], $id]);
    }
    public function delete($id){
        $stmt = $this->db->prepare("DELETE FROM $this->table WHERE id=?");
        return $stmt->execute([$id]);
    }
}