<?php
class Mahasiswa extends Model {
    private $table = 'mahasiswa';
    public function all(){
        $stmt = $this->db->query("SELECT * FROM $this ->table ORDER BY id DESC");
        return $stmt->fetchAll();
    }
    public function find($id){
        $stmt = $this->db->prepare("SELECT * FROM $this->table WHERE id=?");
        $stmt->execute([$id]);
        return $stmt->fetch();
    }
    public function create($data){
        $stmt = $this->db->prepare("INSERT INTO $this->table (nim ,nama, jurusan, email, foto VALUES (?,?,?,?,?");
        return $stmt->execute ([$data['nim'],$data['nama'],$data['jurusan'],$data['email'],$data['foto']]);
    }
    public function update($id,$data){
        $stmt = $this->db->prepare("UPDATE $this->table SET nim=?, nama=?, jurusan=?, email=?, foto=? WHERE id=?");
        return $stmt->execute ([$data['nim'],$data['nama'],$data['jurusan'],$data['email'],$data['foto'], $id]);
    }
    public function delete($id){
        $stmt = $this->db->prepare("DELETE FROM $this->table WHERE id=?");
        return $stmt->execute([$id]);
    }
}