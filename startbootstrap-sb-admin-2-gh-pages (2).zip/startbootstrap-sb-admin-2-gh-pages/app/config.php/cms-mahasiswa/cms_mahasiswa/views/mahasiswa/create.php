<h4>Tambah Mahasiswa</h4>
<form method="post" enctype="multipart/form-data">
    <div class="mb-3"><label>NIM</label><input type="text" name="nim" class="form-control" required></div>
    <div class="mb-3"><label>Nama</label><input type="text" name="nim" class="form-control" required></div>
     <div class="mb-"3><label>Jurusan</label><input type="text" name="nim" class="form-control" required></div>
    <div class="mb-3"><label>Email</label><input type="text" name="nim" class="form-control" required></div>
    <div class="mb-3"><label>Foto</label><input type="text" name="nim" class="form-control" required></div>
    <button class="btn btn-success">Simpan</button>
</form>