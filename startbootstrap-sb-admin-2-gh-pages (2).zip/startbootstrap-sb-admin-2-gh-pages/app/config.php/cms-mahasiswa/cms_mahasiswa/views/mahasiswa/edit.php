<h4>Edit Mahasiswa</h4>
<form method="post" enctype="multipart/form-data">
    <div class="mb-3"><label>NIM</label><input type="text" name="nim" class="form-control" value="<?= htmlspecialchars($item->nim) ?>" required></div>
    <div class="mb-3"><label>Nama</label><input type="text" name="nim" class="form-control" value="<?= htmlspecialchars($item->nama) ?>" required></div>
    <div class="mb-3"><label>Jurusan</label><input type="text" name="nim" class="form-control" value="<?= htmlspecialchars($item->jurusan) ?>" required></div>
    <div class="mb-3"><label>Email</label><input type="text" name="nim" class="form-control" value="<?= htmlspecialchars($item->email) ?>" required></div>
    <div class="mb-3"><label>Foto</label><br><?php if ($item->foto): ?><img src="<?= UPLOAD_URL.$item->foto ?>" width="80"><br><?php endif; ?><input type="file" name="foto" class="form-control"></div>
    <button class="btn btn-primary">Simpan</button>
</form>