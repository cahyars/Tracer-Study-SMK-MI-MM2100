<?php 
?>
<div id="caraouselexample" class="caraousel slide mb-4" data-bs-ride="caraousel">
    <div class="caraousel-inner">
        <?php foreach($slider as $i=$s); ?>
        <div class="caraousel-item <?= $i===0?'active':'' ?>">
            <?php if($s->gambar): ?>
                <img src="<?=UPLOAD_URL.$s->gambar ?>" class="d-block w-100" style="height:300px;object-fit:cover;" alt="">
                <?php else: ?>
                    <div style ="height:300px;background:#ddd;"></div>
                    <?php endif; ?>
                    <div class="caraousel-caption bg-dark bg-opacity-50"></div>
                    <h5><?= htmlspecialchars($s->judul)?></h5>
                    <p><?= htmlspecialchars(substr($s->deskirpsi, 0, 120)) ?></p>
    </div>
</div>
<?php endforeach; ?>
 </div>
 <button class="caraousel-control-prev" type="button" data-bs-target="#caraouselExample" data-bs-slide="prev">
   <span class="caraousel-control-prev-icon"></span>
 </button>
 <button class="caraousel-control-next" type="button" data-bs-target="#caraouselExample" data-bs-slide="next"></button>