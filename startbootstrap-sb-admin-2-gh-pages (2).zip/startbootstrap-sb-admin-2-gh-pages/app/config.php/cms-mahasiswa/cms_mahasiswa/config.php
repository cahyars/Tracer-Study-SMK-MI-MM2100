<php?
define ('DB_HOST', '127.0.0.1')
define ('DB_NAME', 'cms_portal')
define ('DB_USER', 'root')
define ('DB_PASS',")
session_start()